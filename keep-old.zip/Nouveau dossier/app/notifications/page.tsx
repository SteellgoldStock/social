const NotificationsPage = () => {
  return (
    <div>
      <h1>Notifications</h1>
    </div>
  );
}

export default NotificationsPage;